
/**
 * Main AngularJS Web Application
 */
var app = angular.module('tutorialWebApp', [
  'ngRoute'
]);

/**
 * Configure the Routes
 */
app.config(['$routeProvider', function ($routeProvider) {
  $routeProvider
    // Home
    .when("/", {templateUrl: "partials/dashboard.html", controller: "adminCtrl"})
    // Pages
      .when("/refund-transaction", {templateUrl: "partials/refund-transaction.html", controller: "adminCtrl"})
      .when("/transaction-details", {templateUrl: "partials/transaction-details.html", controller: "adminCtrl"})
      .when("/blank", {templateUrl: "partials/blank.html", controller: "adminCtrl"})
    // else 404
    .otherwise("/404", {templateUrl: "partials/404.html", controller: "adminCtrl"});
}]);

/**
 * Controls all other Pages
 */

app.controller('adminCtrl', ['$scope','$http', function($scope,$http) {

    $scope.orderNo = "" ;
    $scope.orderDetails = "";
    $scope.merchantPaymentList="";

    $scope.searchMerchantDetails = function () {
        var reqUrl = 'http://localhost:8080/bctpayadmin/admin/merchant/0' ;
        console.log(reqUrl);
        return $http({
            method : 'GET',
            url :reqUrl
        }).then(function successCallback(response) {
            $scope.merchantPaymentList  = JSON.parse(response.data.merchantDetails);
            console.log($scope.merchantPaymentList );
        }, function errorCallback(response) {
            console.log(response.statusText);
        });
    };

    $scope.searchOrderDetails = function () {
        console.log($scope.orderNo);
        var reqUrl = 'http://localhost:8080/bctpayadmin/admin/merchant/0/paymentDetails/'+ $scope.orderNo ;
        console.log(reqUrl);
        return $http({
            method : 'GET',
            url :reqUrl
        }).then(function successCallback(response) {
          if(response.data != null){
              $scope.orderDetails  = response.data;
           }
        }, function errorCallback(response) {
            console.log(response.statusText);
        });
    };

    $scope.refundTransaction = function () {
        console.log($scope.orderNo);
        var reqUrl = 'http://localhost:8080/bctpayadmin/admin/merchant/0/refund/'+ $scope.orderNo ;
        console.log(reqUrl);
        return $http({
            method : 'GET',
            url :reqUrl
        }).then(function successCallback(response) {
            if(response.data != null){
                $scope.orderDetails  = response.data;
            }
        }, function errorCallback(response) {
            console.log(response.statusText);
        });
    };




}]);


