/**
 * Created by timy on 6/13/17.
 *//*
'use strict';
var app = angular.module ('paymentAdmin', ['ngRoute']);



*/