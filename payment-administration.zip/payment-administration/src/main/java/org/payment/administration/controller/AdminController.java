package org.payment.administration.controller;
 
import com.bct.TwoCheckout.TwoCheckoutService;
import com.bct.model.MerchantConfig;
import com.bct.model.PaymentTransaction;
import com.bct.service.Impl.PaymentServiceImpl;
import com.google.gson.Gson;
import com.twocheckout.Twocheckout;
import com.twocheckout.TwocheckoutException;
import com.twocheckout.TwocheckoutResponse;
import com.twocheckout.model.Sale;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {


	@Autowired
	PaymentServiceImpl paymentCoreService ;


	@RequestMapping(value = "/checkStatus",method = RequestMethod.GET)
	@ResponseBody
    public HttpEntity<ResponseEntity> checkStatus(ModelMap modelMap) {
		modelMap.addAttribute("merchantDetails","Success");
	   return new ResponseEntity(modelMap, org.springframework.http.HttpStatus.OK);
	}

	  /**
     * Get the merchant specific configuration
     *
     * @param merchantId
     * @return
     */
    @RequestMapping(value = "/merchant/{merchantId}/config",method = RequestMethod.GET)
    public String findMerchantConfiguration(@PathVariable  int merchantId,ModelMap model) {
        List<MerchantConfig> merchantConfigs = null;
        try {
            merchantConfigs = paymentCoreService.searchMerchantConfiguration(merchantId);
            Gson gson = new Gson();
            model.addAttribute("merchantDetails", gson.toJson(merchantConfigs));
        }catch (Exception e) {
            e.printStackTrace();
        }

        return "admin" ;
    }


	@RequestMapping(value="/merchant/{merchantId}", method = RequestMethod.GET)
	public HttpEntity<ResponseEntity> getMerchantPaymentDetails(@PathVariable int merchantId, ModelMap model) {
		List<PaymentTransaction> list = paymentCoreService.searchMerchantPaymentDetailedReport(merchantId);
		Gson gson = new Gson();
		System.out.println(gson.toJson(list));
		
		model.addAttribute("merchantDetails", gson.toJson(list));
    	return new ResponseEntity(model, org.springframework.http.HttpStatus.OK);
	}
	
	
	@RequestMapping(value="/merchant/summary/{merchantId}", method = RequestMethod.GET)
	public HttpEntity<ResponseEntity> getMerchantPaymentSummary(@PathVariable int merchantId, ModelMap model) {
		List<PaymentTransaction> list = paymentCoreService.searchMerchantPaymentSummaryReport(merchantId);
		Gson gson = new Gson();
		model.addAttribute("merchantDetails", gson.toJson(list));
		return new ResponseEntity(model, org.springframework.http.HttpStatus.OK);

	}

	/**
	 *
	 * @param merchantId
	 * @param saleId
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/merchant/{merchantId}/refund/{saleId}",method = RequestMethod.GET)
	public String refundTransaction(@PathVariable  int merchantId,@PathVariable String saleId, ModelMap model) {
		Gson gson = new Gson();
		setAccessMode();
		try {
			TwocheckoutResponse twocheckoutResponse = TwoCheckoutService.refundTransaction(saleId);
			model.addAttribute("merchantDetails", gson.toJson(twocheckoutResponse));
		} catch (TwocheckoutException e) {
			String message = e.toString();
			e.printStackTrace();
		}
		return "admin" ;
	}

	/**
	 *
	 * @param merchantId
	 * @param saleId
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/merchant/{merchantId}/paymentDetails/{saleId}",method = RequestMethod.GET)
	public String findTransactionDetails(@PathVariable  int merchantId,@PathVariable String saleId, ModelMap model) {
		Gson gson = new Gson();
		setAccessMode();
		try {
			Sale sale=  com.bct.TwoCheckout.TwoCheckoutService.findTransactionDetails(saleId);
			model.addAttribute("merchantDetails", gson.toJson(sale));
		} catch (TwocheckoutException e) {
			String message = e.toString();
			e.printStackTrace();
		}
		return "admin" ;
	}

	public static void  setAccessMode() {
		Twocheckout.privatekey = "C1E28A9D-8F4C-4ABB-AF7C-AB9C8BA25D0E";
		Twocheckout.mode = "sandbox";
		Twocheckout.apiusername="timy47";
		Twocheckout.apipassword="Pmklissy@88";
	}






}